"use client"

import { useEffect, useState } from "react"
import { BarChart3, PlusCircle, Workflow } from "lucide-react"
import { ProjectCard } from "@/components/project-card"
import { useProjectStore } from "@/lib/store"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export function ProjectsSection() {
  const { getUserProjects, getProjectsByType } = useProjectStore()
  const [powerBiProjects, setPowerBiProjects] = useState<any[]>([])
  const [n8nProjects, setN8nProjects] = useState<any[]>([])
  const [isClient, setIsClient] = useState(false)
  const [hasUserProjects, setHasUserProjects] = useState(false)

  useEffect(() => {
    setIsClient(true)
    // Obter apenas os projetos adicionados pelo usuário
    const userProjects = getUserProjects()
    setHasUserProjects(userProjects.length > 0)

    // Filtrar por tipo e limitar a quantidade exibida
    setPowerBiProjects(userProjects.filter((p) => p.type === "power-bi").slice(0, 4))
    setN8nProjects(userProjects.filter((p) => p.type === "n8n").slice(0, 3))
  }, [getUserProjects])

  // Não renderizar nada durante a hidratação para evitar erros de SSR
  if (!isClient) {
    return null
  }

  // Se não houver projetos adicionados pelo usuário, mostrar mensagem e botão para adicionar
  if (!hasUserProjects) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center">
        <div className="mb-6 text-rfs-black/60 dark:text-rfs-white/60">
          <p className="mb-2">Nenhum projeto em destaque encontrado.</p>
          <p>Adicione projetos na área administrativa para exibi-los aqui.</p>
        </div>
        <Link href="/admin?tab=projects" passHref>
          <Button className="bg-rfs-blue hover:bg-rfs-blue/90 text-rfs-white flex items-center gap-2">
            <PlusCircle className="h-4 w-4" />
            Adicionar Projetos
          </Button>
        </Link>
      </div>
    )
  }

  return (
    <div className="mt-12">
      <div className="space-y-16">
        {powerBiProjects.length > 0 && (
          <div>
            <h3 className="text-2xl font-bold mb-6 flex items-center text-rfs-darkBlue dark:text-rfs-white">
              <BarChart3 className="mr-2 h-6 w-6 text-rfs-blue" />
              Power BI
            </h3>
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {powerBiProjects.map((project) => (
                <ProjectCard
                  key={project.id}
                  title={project.title}
                  description={project.description}
                  type={project.type}
                  image={project.image}
                  slug={project.slug}
                />
              ))}
            </div>
          </div>
        )}

        {n8nProjects.length > 0 && (
          <div>
            <h3 className="text-2xl font-bold mb-6 flex items-center text-rfs-darkBlue dark:text-rfs-white">
              <Workflow className="mr-2 h-6 w-6 text-rfs-blue" />
              Automação n8n
            </h3>
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-3">
              {n8nProjects.map((project) => (
                <ProjectCard
                  key={project.id}
                  title={project.title}
                  description={project.description}
                  type={project.type}
                  image={project.image}
                  slug={project.slug}
                />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
