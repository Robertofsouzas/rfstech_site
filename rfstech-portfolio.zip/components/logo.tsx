"use client"

import { useTheme } from "@/components/theme-provider"

export function Logo({ size = "default" }: { size?: "default" | "small" | "large" }) {
  const { theme } = useTheme()

  // Definir tamanhos com base no parâmetro
  const sizes = {
    small: "h-8 text-lg",
    default: "h-10 text-xl",
    large: "h-12 text-2xl",
  }

  const sizeClass = sizes[size] || sizes.default

  return (
    <div className={`flex items-center gap-2 font-bold ${sizeClass}`}>
      <div className={`flex items-center justify-center rounded-md bg-rfs-blue text-white aspect-square h-full`}>
        <span className="font-bold">RFS</span>
      </div>
      <span className="text-rfs-darkBlue dark:text-rfs-white">tech</span>
    </div>
  )
}
